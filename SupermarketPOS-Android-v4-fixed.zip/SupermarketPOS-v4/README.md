# Supermarket POS v4

Android supermarket POS starter app.

Build requirements:
- Java 17
- Gradle 8.10.2
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35

The app module explicitly uses Java/Kotlin JVM 17 and Kotlin JVM toolchain 17 to avoid JVM-target mismatch errors.
